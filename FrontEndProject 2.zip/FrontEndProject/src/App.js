import './App.css';
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import MovieReviewList from './Fetch';
import Header from './Header';
import HomePage from './HomePage';
import Search from './SearchBar';

function App() {
  return (
    <div className="app-container">
      
      <Header />

      
      <div className="app-content">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/moviereviews" element={<MovieReviewList />} />
          <Route path="/search" element={<Search />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
